//Mark E. Lehr
//November 7th, 2006
//Deck Specification

#ifndef DECK_H
#define DECK_H

#include "BJCard.h"
class Deck
{
	private:
		BJCard **deck;
		int *index;
	public:
		Deck(void);
		~Deck(void);
		void shuffle(void);
		BJCard **deal(void);
};
#endif