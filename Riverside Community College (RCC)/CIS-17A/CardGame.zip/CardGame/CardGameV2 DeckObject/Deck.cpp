//Mark E. Lehr
//November 7th, 2006
//Deck Implementation

#include "Deck.h"

Deck::Deck(void)
{
	//Create the Deck array
	deck=new BJCard*[52];
	index=new int[52];
	for(int i=0;i<52;i++)
	{
		deck[i]=new BJCard(i);
		index[i]=i;
	}
}
Deck::~Deck(void)
{
	//Destroy for any memory leaks
	for(int i=0;i<52;i++)
	{
		delete deck[i];
	}
	delete []deck;
	delete []index;
}
void Deck::shuffle(void)
{
}
BJCard **Deck::deal(void)
{
	BJCard **ret=new BJCard*[2];
	ret[0]=deck[0];
	ret[1]=deck[1];
	return ret;
}
