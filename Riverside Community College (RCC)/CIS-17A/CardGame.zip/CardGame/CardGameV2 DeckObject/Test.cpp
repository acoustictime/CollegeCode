//Mark E. Lehr
//November 7th, 2006
//Test of Cards, etc...

#include <iostream>
using namespace std;

#include "Deck.h"

int main(int argv,char *argc[])
{
	//Create a deck
	Deck d;
	BJCard **c=d.deal();
	cout<<c[0]->getFace()<<c[0]->getSuit()<<"="<<c[0]->getValue()<<endl;
	cout<<c[1]->getFace()<<c[1]->getSuit()<<"="<<c[1]->getValue()<<endl;
}