//Mark E. Lehr
//November 7th, 2006
//Deck Specification
//December 5th, added shuffling and
//filling the deck
//Also, now uses a template which is
//valid for the Card or BJCard Class

#ifndef DECK_H
#define DECK_H

template <class T>
class Deck
{
	private:
		T **deck;
		int *index;
		int cardPos;
	public:
		Deck(void);
		~Deck(void);
		void shuffle(void);
		T *deal(void);
};
#endif

#include <ctime>
#include <cstdlib>
using namespace std;

template <class T>
Deck<T>::Deck(void)
{
	//Create the Deck array
	cardPos=0;
	deck=new T*[52];
	index=new int[52];
	for(int i=0;i<52;i++)
	{
		deck[i]=new T(i);
		index[i]=i;
	}
	srand(static_cast<unsigned int>(time(0)));
}

template <class T>
Deck<T>::~Deck(void)
{
	//Destroy for any memory leaks
	for(int i=0;i<52;i++)
	{
		delete deck[i];
	}
	delete []deck;
	delete []index;
}

template <class T>
void Deck<T>::shuffle(void)
{
	for(int shuf=1;shuf<=5;shuf++)
	{
		for(int i=0;i<52;i++)
		{
			int rindx=rand()%52;
			int temp=index[i];
			index[i]=index[rindx];
			index[rindx]=temp;
		}
	}
	cardPos=0;
}

template <class T>
T *Deck<T>::deal(void)
{
	if(cardPos>=52)shuffle();
	return deck[index[cardPos++]];
}
