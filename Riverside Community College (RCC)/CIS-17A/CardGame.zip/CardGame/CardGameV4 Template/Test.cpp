//Mark E. Lehr
//December 5th, 2006
//Shuffle Deck and Display the cards
//Note a templated Class is used

#include <iostream>
using namespace std;

#include "BJCard.h"
#include "Deck.h"

int main(int argv,char *argc[])
{
	//Create a deck, shuffle and display the
	//shuffled deck with regular cards
	Deck<Card> d;
	d.shuffle();
	for(int i=0;i<52;i++)
	{
		Card *card=d.deal();
		cout<<card->getFace()<<card->getSuit()<<"="<<card->getValue()<<endl;
	}
	cout<<endl;

	//Create a deck, shuffle and display the
	//shuffled deck with black jack cards
	Deck<BJCard> bjd;
	bjd.shuffle();
	for(int i=0;i<52;i++)
	{
		BJCard *c=bjd.deal();
		cout<<c->getFace()<<c->getSuit()<<"="<<c->getValue()<<endl;
	}
}