//Mark E. Lehr
//November 7th, 2006
//Test of Cards, etc...

#include <iostream>
using namespace std;

#include "BJCard.h"

int main(int argv,char *argc[])
{
	//Declare cards and output the result
	for(int i=0;i<52;i++)
	{
		Card card(i);
		cout<<card.getFace()<<card.getSuit()<<" ";
		if(i%13==12)cout<<endl;
	}

	//Declare black jack cards and output the result
	cout<<endl<<endl;
	for(int i=0;i<52;i++)
	{
		BJCard bjcard(i);
		cout<<bjcard.getValue()<<" ";
		if(i%13==12)cout<<endl;
	}

	//Array of cards to become the deck
	BJCard **deck=new BJCard*[52];
	for(int i=0;i<52;i++)
	{
		deck[i]=new BJCard(i);
	}

	//Destroy for any memory leaks
	for(int i=0;i<52;i++)
	{
		delete deck[i];
	}
	delete []deck;
}