//Mark E. Lehr
//November 7th, 2006
//Black Jack Card Specification
//Inherited from Card

#ifndef BJCARD_H
#define BJCARD_H

#include "Card.h"

class BJCard:public Card
{
	public:

		//Constructor
		BJCard(int n):Card(n){};

		int getValue()
		{
			char f=getFace();
			if(f>48&&f<58)return f-48;
			else if(f>65) return 10;
			else return 11;
		};
};

#endif
