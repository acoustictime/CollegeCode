//Mark E. Lehr
//November 7th, 2006
//Card Implementation

#include "Card.h"

		char number;

Card::Card(int n)
{
	if(n>=0) number=n%52;
	else n=0;
}
char Card::getFace()
{
	static char F[]={'A','2','3','4',
		             '5','6','7','8',
					 '9','T','J','Q','K'};
	return F[number%13];
}
char Card::getSuit()
{
	static char S[]={'S','H','C','D'};
	if(number<13)     return S[0];
	else if(number<26)return S[1];
	else if(number<39)return S[2];
	else              return S[3];
}