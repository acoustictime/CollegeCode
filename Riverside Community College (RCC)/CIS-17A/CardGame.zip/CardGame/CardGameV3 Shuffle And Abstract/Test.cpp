//Mark E. Lehr
//December 5th, 2006
//Shuffle Deck and Display the cards

#include <iostream>
using namespace std;

#include "Deck.h"

int main(int argv,char *argc[])
{
	//Create a deck, shuffle and display the
	//shuffled deck
	Card card(1);
	Deck d;
	d.shuffle();
	for(int i=0;i<52;i++)
	{
		BJCard *c=d.deal();
		cout<<c->getFace()<<c->getSuit()<<"="<<c->getValue()<<endl;
	}
}