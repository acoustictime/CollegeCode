//Mark E. Lehr
//November 7th, 2006
//Deck Specification
//December 5th, added shuffling and
//filling the deck

#ifndef DECK_H
#define DECK_H

#include "BJCard.h"
class Deck
{
	private:
		BJCard **deck;
		int *index;
		int cardPos;
	public:
		Deck(void);
		~Deck(void);
		void shuffle(void);
		BJCard *deal(void);
};
#endif