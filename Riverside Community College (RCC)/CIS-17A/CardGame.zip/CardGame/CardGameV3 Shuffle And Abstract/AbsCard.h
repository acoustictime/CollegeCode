//Mark E. Lehr 
//December 5th, 2006
//Abstract Card Specification

#ifndef ABSCARD_H
#define ABSCARD

class AbsCard
{
	public:
		virtual char getFace()=0;
		virtual char getSuit()=0;
		virtual int  getValue()=0;
};

#endif