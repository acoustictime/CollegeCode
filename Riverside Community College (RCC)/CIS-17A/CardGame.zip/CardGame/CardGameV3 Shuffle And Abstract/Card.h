//Mark E. Lehr 
//November 7th, 2006
//Card Specification

#ifndef CARD_H
#define CARD

#include "AbsCard.h"

class Card:public AbsCard
{
	private:
		char number;
	public:
		Card(int);//Constructor
		char getFace();
		char getSuit();
		int  getValue(){return 0;};
};

#endif