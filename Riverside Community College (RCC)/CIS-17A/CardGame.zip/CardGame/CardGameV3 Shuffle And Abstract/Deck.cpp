//Mark E. Lehr
//November 7th, 2006
//Deck Implementation
//December 5th, added shuffling and
//filling the deck

#include "Deck.h"
#include <ctime>
#include <cstdlib>
using namespace std;

Deck::Deck(void)
{
	//Create the Deck array
	cardPos=0;
	deck=new BJCard*[52];
	index=new int[52];
	for(int i=0;i<52;i++)
	{
		deck[i]=new BJCard(i);
		index[i]=i;
	}
	srand(static_cast<unsigned int>(time(0)));
}
Deck::~Deck(void)
{
	//Destroy for any memory leaks
	for(int i=0;i<52;i++)
	{
		delete deck[i];
	}
	delete []deck;
	delete []index;
}
void Deck::shuffle(void)
{
	for(int shuf=1;shuf<=5;shuf++)
	{
		for(int i=0;i<52;i++)
		{
			int rindx=rand()%52;
			int temp=index[i];
			index[i]=index[rindx];
			index[rindx]=temp;
		}
	}
	cardPos=0;
}
BJCard *Deck::deal(void)
{
	if(cardPos>=52)shuffle();
	return deck[index[cardPos++]];
}
