
public class cube extends threeDimensional
{
	public void name()
	{
		super.name();
		System.out.print("I am a cube\n");
		
	}
}
