
public class rhombus extends twoDimensional
{
	public void name()
	{
		super.name();
		System.out.print("I am a rhombus\n");
	}
}
