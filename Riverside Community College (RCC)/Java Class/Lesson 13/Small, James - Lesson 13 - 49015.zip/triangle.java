
public class triangle extends twoDimensional
{
	public void name()
	{
		super.name();
		System.out.print("I am a triangle\n");
	}
}
