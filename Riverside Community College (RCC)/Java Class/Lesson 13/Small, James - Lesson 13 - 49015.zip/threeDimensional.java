
public class threeDimensional extends Shape
{
	public void name()
	{
		super.name();
		System.out.print("I am a three dimensional shape\n");
		
	}
}
