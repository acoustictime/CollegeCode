
public class Shape 
{
	public void name()
	{
		System.out.print("I am a shape\n");
	}


}
