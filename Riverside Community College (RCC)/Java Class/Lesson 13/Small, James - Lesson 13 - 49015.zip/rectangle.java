
public class rectangle extends twoDimensional
{
	public void name()
	{
		super.name();
		System.out.print("I am a rectangle\n");
	}
}
