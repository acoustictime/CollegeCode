
public class rhombohedron extends threeDimensional
{
	public void name()
	{
		super.name();
		System.out.print("I am a rhombohedron\n");
		
	}
}
