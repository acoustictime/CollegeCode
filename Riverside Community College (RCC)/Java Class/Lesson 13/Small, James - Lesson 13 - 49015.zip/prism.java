
public class prism extends threeDimensional
{
	public void name()
	{
		super.name();
		System.out.print("I am a prism\n");
		
	}
}
