
public class pyramid extends threeDimensional
{
	public void name()
	{
		super.name();
		System.out.print("I am a pyramid\n");
		
	}
}
