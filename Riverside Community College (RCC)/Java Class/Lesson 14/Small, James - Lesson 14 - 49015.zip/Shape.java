
public abstract class Shape 
{
	public abstract double getArea();
	public abstract double getVolume();
}
