
public abstract class twoDimensionalShape extends Shape
{

	public abstract double getArea();
	
}
