////////////////////////////////////////////////////////////////////////
 
 
// Fig. 3.15: ClassDate.java
// ClassDate with initializer for month, day, and year


public class ClassDate 
{
	
	//instance variables
	private String dateMonth;
	private int dateDay;
	private int dateYear;
	
	public ClassDate(String month, int day, int year ) //Constructor initializes values.
	{
		dateMonth = month;
		dateDay = day;
		dateYear = year;
	}
	
	public void setMonth(String month) //Set Month Method
	{
		dateMonth = month; // Assign month to instance variable
	}
	
	public String getMonth() // Get month Method
	{
		return dateMonth; // Return month
	}
	
	public void setDay(int day) //Set day Method
	{
		dateDay = day; // Assign day to instance variable
	}
	
	public int getDay() // Get day Method
	{
		return dateDay; // Return day
	}
	
	public void setYear(int year) //Set year Method
	{
		dateYear = year; // Assign year to instance variable
	}

	public int getYear() // Get year Method
	{
		return dateYear; // Return year
	}
		
		public void displayDate() //Displays current date
		{
			System.out.printf("\nThe date is %s %d, %d\n",dateMonth,dateDay,dateYear);
		}

}
