// Fig. 3.13: Account.java
// Account class with a constructor to
// initialize instance variable balance.
 
public class Account
{  
   private double balance; // instance variable that stores the balance
 
   // constructor 
   public Account( double initialBalance )
   {
      // validate that initialBalance is greater than 0.0;
      // if it is not, balance is initialized to the default value 0.0
      if ( initialBalance > 0.0 )
         balance = initialBalance;
   } // end Account constructor
 
   // credit (add) an amount to the account
   public void credit( double amount )
   {     
      balance = balance + amount; // add amount to balance
   } // end method credit
   
   public void debit( double amount )
   {     
	   if (amount > balance)
		   System.out.printf("The amount of your withdrawl of %f is too large, try again!!\n", amount); 
		   
	   if (amount <= balance)
		   balance = balance - amount; // subtract amount from balance
	   
	   if (amount <= balance)
		   System.out.printf("You withdrew %f from your account, your current balance is %f!!\n", amount,balance);
	   
   } // end method debit
 
   // return the account balance
   public double getBalance()
   {
      return balance; // gives the value of balance to the calling method
   } // end method getBalance
 
} // end class Account

