
public class Class 
{
	
	private String dateMonth;
	private int dateDay;
	private int dateYear;
	
	public Class(String month, int day, int year )
	{
		dateMonth = month;
		dateDay = day;
		dateYear = year;
	}
	
	public void setMonth(String month) //Set Month Method
	{
		dateMonth = month; // Assign month to instance variable
	}
	
	public String getMonth() // Get month Method
	{
		return dateMonth; // Return month
	}
	
	public void setDay(int day) //Set day Method
	{
		dateDay = day; // Assign day to instance variable
	}
	
	public int getDay() // Get day Method
	{
		return dateDay; // Return day
	}
	
	public void setYear(int year) //Set year Method
	{
		dateYear = year; // Assign year to instance variable
	}

	public int getYear() // Get year Method
	{
		return dateYear; // Return year
	}
		
		public void displayDate()
		{
			System.out.printf("\nThe date is %s %d, %d",dateMonth,dateDay,dateYear);
		}

}
