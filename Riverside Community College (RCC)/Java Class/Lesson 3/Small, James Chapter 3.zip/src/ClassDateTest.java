////////////////////////////////////////////////////////////////////////
 
 
// Fig. 3.15: ClassDateTest.java
// ClassDateTest that defines ClassDate object with initial values.  Allow
// you to enter new date as well

import java.util.Scanner;


public class ClassDateTest {
	
	public static void main(String args[])
	{
		
		Scanner input = new Scanner(System.in);
		
		ClassDate myClassDate = new ClassDate("January", 26, 1982); //Create ClassDate object with initial values
		
		myClassDate.displayDate(); // display date
		
		System.out.println("\nPlease enter the month: "); //Input month
		String theMonth = input.nextLine();
		myClassDate.setMonth(theMonth);
		
		System.out.println("\nPlease enter the day: "); // Input Day
		int theDay = input.nextInt();
		myClassDate.setDay(theDay);
		
		System.out.println("\nPlease enter the year: "); // Input Year
		int theYear = input.nextInt();
		myClassDate.setYear(theYear);
		
		myClassDate.displayDate(); // Display date		
	}

}
